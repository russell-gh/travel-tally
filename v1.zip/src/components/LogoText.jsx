export const LogoText = () => {
  return (
    <div className="logoText" id="LogoText">
      <img src="../src/img/LogoTextOnly.png" />
    </div>
  );
};

export default LogoText;
