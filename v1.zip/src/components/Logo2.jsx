export const Logo2 = () => {
  return (
    <div className="logo2" id="logo2">
      <img src="../src/img/LogoOnly.png" />
    </div>
  );
};

export default Logo2;
